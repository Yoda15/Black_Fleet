#ifndef PLATEAU_H_INCLUDED
#define PLATEAU_H_INCLUDED

void Affichage_Plateau(S_Case P[][Long],Joueur J[],fregate F[]);
void color(int couleurDuTexte,int couleurDeFond);
void Affichage_Bateau(S_Case P[][Long],fregate F[],int i,int j,Joueur J[],int c);

#endif // PLATEAU_H_INCLUDED
