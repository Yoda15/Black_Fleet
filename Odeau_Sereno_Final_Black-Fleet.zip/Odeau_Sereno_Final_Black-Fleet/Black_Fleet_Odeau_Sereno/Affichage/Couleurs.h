#ifndef COULEURS_H_INCLUDED
#define COULEURS_H_INCLUDED
#include "../Objets.h"
void color(int couleurDuTexte,int couleurDeFond);
void nom_couleur(Joueur J,char t[]);

#endif // COULEURS_H_INCLUDED
