#ifndef FIN_PARTIE_H_INCLUDED
#define FIN_PARTIE_H_INCLUDED

void Fin_de_partie(Joueur J[]);

#endif // FIN_PARTIE_H_INCLUDED
