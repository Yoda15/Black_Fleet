#ifndef PLACEMENTS_H_INCLUDED
#define PLACEMENTS_H_INCLUDED

void Placement_Bateau(Joueur *J, S_Case P[][Long], fregate F[]);

#endif // PLACEMENTS_H_INCLUDED
