#ifndef MESSAGE_H_INCLUDED
#define MESSAGE_H_INCLUDED

void Messages(int a);

#endif // MESSAGE_H_INCLUDED
