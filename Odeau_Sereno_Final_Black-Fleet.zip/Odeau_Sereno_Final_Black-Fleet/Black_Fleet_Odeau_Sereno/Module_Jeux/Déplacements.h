#ifndef DEPLACEMENTS_H_INCLUDED
#define DEPLACEMENTS_H_INCLUDED

void Deplacements(Joueur J[], S_Case P[][Long], fregate F[], int j, int tab[]);

#endif // D�PLACEMENTS_H_INCLUDED
