#ifndef CARTES_H_INCLUDED
#define CARTES_H_INCLUDED

void Achat_Carte(Joueur *J);
void Cartes_Aleatoire(int tab[], Joueur J);

#endif // CARTES_H_INCLUDED
