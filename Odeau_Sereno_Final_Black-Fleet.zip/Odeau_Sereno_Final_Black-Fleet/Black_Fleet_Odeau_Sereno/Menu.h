#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED

int menu();
void Regles();

#endif // MENU_H_INCLUDED
