#ifndef FICHIERS_H_INCLUDED
#define FICHIERS_H_INCLUDED

void Affichage_Fichier_ESTACA();
void Affichage_Fichier_SON();

#endif // FICHIERS_H_INCLUDED
