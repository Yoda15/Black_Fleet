#ifndef FONCTIONS_INITIALISATION_H_INCLUDED
#define FONCTIONS_INITIALISATION_H_INCLUDED

void Initialisation(Joueur J[], fregate F[], int nbj);
void initialiser_Plateau(S_Case P[][Long]);

#endif // FONCTIONS_INITIALISATION_H_INCLUDED
