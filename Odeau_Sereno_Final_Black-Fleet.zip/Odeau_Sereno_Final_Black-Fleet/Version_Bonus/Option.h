#ifndef OPTION_H_INCLUDED
#define OPTION_H_INCLUDED

void Option(int *nbj,int *difficulte,int *vitesse);

#endif // OPTION_H_INCLUDED
